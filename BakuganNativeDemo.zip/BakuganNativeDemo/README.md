# Bakugan Native Demo (prototipo técnico)

Prototipo inicial Android con Activity Java + renderizador C++ nativo (NDK) + OpenGL ES 2.0.
No contiene assets oficiales ni código extraído del juego original.

## Qué incluye
- Ventana horizontal inmersiva.
- Renderizado OpenGL ES desde C++.
- Arena estilizada y esfera provisional que representa un Bakugan.
- Controles táctiles izquierda/derecha y botón de lanzamiento.
- Estructura preparada para ir reemplazando el prototipo por sistemas reales.

## Requisitos
- Android Studio reciente
- Android SDK Platform 35
- Android NDK (Side by side)
- CMake 3.22.1
- JDK 17

## Compilar
1. Descomprimir el ZIP.
2. Abrir la carpeta `BakuganNativeDemo` en Android Studio.
3. Esperar la sincronización de Gradle e instalar los componentes que solicite.
4. Conectar el teléfono con depuración USB activada.
5. Ejecutar la configuración `app`.

También se puede compilar desde la terminal del proyecto:
`./gradlew assembleDebug`
(En Windows: `gradlew.bat assembleDebug`)

APK esperado:
`app/build/outputs/apk/debug/app-debug.apk`

## Controles de la demo
- Tocar la mitad izquierda: mover el Bakugan hacia la izquierda.
- Tocar la mitad derecha: moverlo hacia la derecha.
- Botón LAUNCH: iniciar un pequeño movimiento de lanzamiento.

## Siguiente hito
Añadir cámara/perspectiva real, geometría de esfera mejorada, colisiones, cartas y sistema de combate. Luego investigar la estructura de una copia legítima de la ISO para identificar formatos de recursos.
