#include <jni.h>
#include <GLES2/gl2.h>
#include <android/log.h>
#include <cmath>
#include <vector>
#include <algorithm>

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "BakuganDemo", __VA_ARGS__)

static GLuint program = 0;
static GLint posLoc = -1, colorLoc = -1;
static float aspect = 1.0f;
static float moveInput = 0.0f;
static float ballX = 0.0f;
static float launchTime = 0.0f;
static float elapsed = 0.0f;

static const char* VS =
    "attribute vec2 aPos; uniform vec4 uColor; varying vec4 vColor;"
    "void main(){ gl_Position=vec4(aPos,0.0,1.0); gl_PointSize=1.0; vColor=uColor; }";
static const char* FS =
    "precision mediump float; varying vec4 vColor;"
    "void main(){ gl_FragColor=vColor; }";

static GLuint compileShader(GLenum type, const char* source) {
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &source, nullptr);
    glCompileShader(s);
    GLint ok = 0; glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char log[1024]; glGetShaderInfoLog(s, sizeof(log), nullptr, log);
        LOGI("Shader error: %s", log);
    }
    return s;
}

static void draw(const std::vector<float>& vertices, GLenum mode,
                 float r, float g, float b, float a = 1.0f) {
    if (vertices.empty() || !program) return;
    glUseProgram(program);
    glUniform4f(colorLoc, r, g, b, a);
    glEnableVertexAttribArray(posLoc);
    glVertexAttribPointer(posLoc, 2, GL_FLOAT, GL_FALSE, 0, vertices.data());
    glDrawArrays(mode, 0, (GLsizei)(vertices.size()/2));
    glDisableVertexAttribArray(posLoc);
}

static void quad(float x1,float y1,float x2,float y2,float x3,float y3,
                 float x4,float y4,float r,float g,float b) {
    draw({x1,y1,x2,y2,x3,y3,x1,y1,x3,y3,x4,y4}, GL_TRIANGLES, r,g,b);
}

static void circle(float cx, float cy, float radius, float r,float g,float b,
                   int segments=48) {
    std::vector<float> v;
    v.reserve((segments+2)*2);
    v.push_back(cx); v.push_back(cy);
    for (int i=0;i<=segments;i++) {
        float a = (float)i * 6.28318530718f / (float)segments;
        v.push_back(cx + std::cos(a)*radius);
        v.push_back(cy + std::sin(a)*radius);
    }
    draw(v, GL_TRIANGLE_FAN, r,g,b);
}

extern "C" JNIEXPORT void JNICALL
Java_dev_bakugan_native_1demo_MainActivity_nativeInit(JNIEnv*, jclass) {
    GLuint vs = compileShader(GL_VERTEX_SHADER, VS);
    GLuint fs = compileShader(GL_FRAGMENT_SHADER, FS);
    program = glCreateProgram();
    glAttachShader(program, vs); glAttachShader(program, fs);
    glLinkProgram(program);
    glDeleteShader(vs); glDeleteShader(fs);
    posLoc = glGetAttribLocation(program, "aPos");
    colorLoc = glGetUniformLocation(program, "uColor");
    glDisable(GL_DEPTH_TEST);
    glClearColor(0.035f,0.055f,0.10f,1.0f);
    LOGI("Native renderer initialized");
}

extern "C" JNIEXPORT void JNICALL
Java_dev_bakugan_native_1demo_MainActivity_nativeResize(JNIEnv*, jclass,
                                                        jint w, jint h) {
    glViewport(0,0,w,h);
    aspect = h > 0 ? (float)w/(float)h : 1.0f;
}

extern "C" JNIEXPORT void JNICALL
Java_dev_bakugan_native_1demo_MainActivity_nativeSetMove(JNIEnv*, jclass, jfloat v) {
    moveInput = std::max(-1.0f, std::min(1.0f, (float)v));
}

extern "C" JNIEXPORT void JNICALL
Java_dev_bakugan_native_1demo_MainActivity_nativeLaunch(JNIEnv*, jclass) {
    launchTime = 0.001f;
}

extern "C" JNIEXPORT void JNICALL
Java_dev_bakugan_native_1demo_MainActivity_nativeRender(JNIEnv*, jclass, jfloat dt) {
    elapsed += dt;
    ballX += moveInput * dt * 0.9f;
    ballX = std::max(-0.72f, std::min(0.72f, ballX));
    if (launchTime > 0.0f) launchTime += dt;
    if (launchTime > 1.2f) launchTime = 0.0f;

    glClear(GL_COLOR_BUFFER_BIT);

    // Fondo: horizonte y suelo.
    quad(-1,-1, 1,-1, 1,0.05f, -1,0.05f, 0.075f,0.12f,0.20f);
    quad(-1,0.05f, 1,0.05f, 1,0.24f, -1,0.24f, 0.12f,0.19f,0.27f);

    // Arena geométrica estilizada.
    quad(-0.86f,-0.56f, 0.86f,-0.56f, 0.70f,0.18f, -0.70f,0.18f,
         0.18f,0.22f,0.28f);
    quad(-0.78f,-0.49f, 0.78f,-0.49f, 0.63f,0.10f, -0.63f,0.10f,
         0.25f,0.30f,0.37f);
    // Marcas de la arena.
    quad(-0.68f,-0.40f, 0.68f,-0.40f, 0.65f,-0.37f, -0.65f,-0.37f,
         0.78f,0.36f,0.12f);
    quad(-0.54f,-0.18f, 0.54f,-0.18f, 0.52f,-0.16f, -0.52f,-0.16f,
         0.78f,0.36f,0.12f);

    // Círculo de sombra y Bakugan provisional.
    float y = -0.17f;
    if (launchTime > 0.0f) {
        float t = std::min(1.0f, launchTime/1.2f);
        y += std::sin(t*3.14159265f)*0.42f;
    }
    circle(ballX, -0.27f, 0.105f, 0.015f,0.025f,0.04f);
    circle(ballX, y, 0.085f, 0.70f,0.10f,0.07f);
    circle(ballX-0.018f, y+0.025f, 0.048f, 0.91f,0.20f,0.10f);
    circle(ballX-0.030f, y+0.038f, 0.012f, 1.0f,0.72f,0.30f);
    // Brillo lateral.
    circle(ballX+0.040f, y-0.020f, 0.012f, 0.35f,0.04f,0.04f);

    // Indicador decorativo de energía.
    float pulse = 0.5f + 0.5f*std::sin(elapsed*3.0f);
    quad(-0.30f,0.72f, 0.30f,0.72f, 0.30f,0.75f, -0.30f,0.75f,
         0.16f,0.20f,0.28f);
    quad(-0.30f,0.72f, -0.30f+0.60f*pulse,0.72f,
         -0.30f+0.60f*pulse,0.75f, -0.30f,0.75f,
         0.90f,0.29f,0.10f);
}
