package dev.bakugan.native_demo;

import android.app.Activity;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

public final class MainActivity extends Activity {
    static { System.loadLibrary("bakugan_demo"); }

    private GLSurfaceView glView;
    private TextView launchButton;

    private static native void nativeInit();
    private static native void nativeResize(int width, int height);
    private static native void nativeRender(float dt);
    private static native void nativeSetMove(float amount);
    private static native void nativeLaunch();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        );

        FrameLayout root = new FrameLayout(this);
        glView = new GLSurfaceView(this);
        glView.setEGLContextClientVersion(2);
        glView.setRenderer(new GLSurfaceView.Renderer() {
            private long last = 0;
            @Override public void onSurfaceCreated(javax.microedition.khronos.opengles.GL10 gl,
                    javax.microedition.khronos.egl.EGLConfig config) { nativeInit(); }
            @Override public void onSurfaceChanged(javax.microedition.khronos.opengles.GL10 gl,
                    int width, int height) { nativeResize(width, height); }
            @Override public void onDrawFrame(javax.microedition.khronos.opengles.GL10 gl) {
                long now = System.nanoTime();
                float dt = last == 0 ? 0.016f : Math.min((now-last)/1_000_000_000.0f, 0.05f);
                last = now;
                nativeRender(dt);
            }
        });
        glView.setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
        root.addView(glView);

        TextView title = new TextView(this);
        title.setText("BAKUGAN  •  NATIVE PROTOTYPE");
        title.setTextColor(0xffffffff);
        title.setTextSize(16);
        title.setShadowLayer(5, 2, 2, 0xff000000);
        FrameLayout.LayoutParams titleLp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        titleLp.topMargin = dp(14);
        root.addView(title, titleLp);

        TextView help = new TextView(this);
        help.setText("TOCÁ IZQ./DER. PARA MOVER");
        help.setTextColor(0xffeeeeee);
        help.setTextSize(12);
        FrameLayout.LayoutParams helpLp = new FrameLayout.LayoutParams(-2, -2,
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        helpLp.bottomMargin = dp(15);
        root.addView(help, helpLp);

        launchButton = new TextView(this);
        launchButton.setText("  LAUNCH  ");
        launchButton.setTextColor(0xffffffff);
        launchButton.setTextSize(16);
        launchButton.setGravity(Gravity.CENTER);
        launchButton.setBackgroundColor(0xffb52d21);
        launchButton.setElevation(dp(6));
        FrameLayout.LayoutParams launchLp = new FrameLayout.LayoutParams(-2, dp(52),
                Gravity.RIGHT | Gravity.BOTTOM);
        launchLp.rightMargin = dp(22);
        launchLp.bottomMargin = dp(48);
        root.addView(launchButton, launchLp);
        launchButton.setOnClickListener(v -> {
            glView.queueEvent(MainActivity::nativeLaunch);
        });

        glView.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN ||
                event.getAction() == MotionEvent.ACTION_MOVE) {
                float x = event.getX() / Math.max(1f, v.getWidth());
                float amount = x < 0.42f ? -1f : (x > 0.58f ? 1f : 0f);
                glView.queueEvent(() -> nativeSetMove(amount));
                return true;
            }
            if (event.getAction() == MotionEvent.ACTION_UP ||
                event.getAction() == MotionEvent.ACTION_CANCEL) {
                glView.queueEvent(() -> nativeSetMove(0f));
                return true;
            }
            return false;
        });

        setContentView(root);
    }

    private int dp(int value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override protected void onPause() {
        super.onPause();
        if (glView != null) glView.onPause();
    }
    @Override protected void onResume() {
        super.onResume();
        if (glView != null) glView.onResume();
    }
}
